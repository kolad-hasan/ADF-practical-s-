# ADF Practicals

**App Development with Flutter — Practical Files**

This repository contains the practical files provided for the ADF (App Development with Flutter) coursework.

## Practicals Included

| Folder | Topic / File |
|---|---|
| Practical-03 | Dart OOP concepts: class/static number, single inheritance, multilevel inheritance, multiple interfaces, mixin |
| Practical-04 | Flutter arithmetic calculator |
| Practical-04-Calculator | Additional arithmetic calculator practical |
| Practical-05 | Practical 5 PDF |
| Practical-06-07 | Login validation and page navigation using pushName |
| Practical-08 | Practical 8 PDF |
| Practical-08B | Registration form practical |
| Practical-09 | External URL navigation |
| Practical-10 | Flutter gestures: tap, double/long press, pinch zoom, drag |
| Practical-11 | Firebase Authentication |

## How to use

1. Download or clone this repository.
2. Open the required practical folder.
3. Open the PDF to view the code, steps, and output screenshots.
4. Recreate the Dart/Flutter files in Android Studio or VS Code when required.

## Repository Name

**ADF-Practicals**

> The GitHub-friendly repository name uses a hyphen. The displayed project title is **ADF Practicals**.

## Student

Mohamad Hasan Kolad

## Technology

- Dart
- Flutter
- Firebase Authentication
